export const environment = {
  production: true,
  apiURL: "../VMSAPI/api/"
};
